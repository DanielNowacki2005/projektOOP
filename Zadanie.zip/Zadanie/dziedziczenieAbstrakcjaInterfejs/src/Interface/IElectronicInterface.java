package Interface;

public interface IElectronicInterface {

    public  double  addToPrice(double newPrice);
    public  double  saleReturn(double saleAmount);
}
