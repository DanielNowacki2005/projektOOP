package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateViews {
    protected int viewFocus = 0;
    //creates main view
    JButton borrow=new JButton("borrow");
    JButton unBorrow=new JButton("unBorrow");
    JButton renew=new JButton("renew");
    JButton see=new JButton("see");
    JButton add=new JButton("add");
    JButton delete=new JButton("delete");
    JButton returnToBack = new JButton("return");
    JFrame borrowFrame=new JFrame();
    JFrame unBorrowFrame=new JFrame();
    JFrame renewFrame=new JFrame();
    JFrame addFrame=new JFrame();
    JFrame deleteFrame=new JFrame();
    JFrame seeFrame=new JFrame();
    JFrame f=new JFrame();

    JLabel nameLabel = new JLabel("author name");
    JTextField name = new JTextField();
    JLabel secondNameLabel = new JLabel("author second name");
    JTextField secondName = new JTextField();
    JLabel titleLabel = new JLabel("book title");
    JTextField uczenId = new JTextField();
    JLabel uczenIdLabel = new JLabel("uczenId");
    JTextField title = new JTextField();
    JLabel typeLabel = new JLabel("book type");
    JTextField typeField = new JTextField();
    JButton addBookButton = new JButton("Add book");
    JButton seeBook = new JButton("See book");
    JButton deleteBook = new JButton("delete book");
    JLabel label = new JLabel("Bibiolteka");



    public CreateViews() {


        label.setVerticalAlignment(JLabel.BOTTOM);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setBounds(100,60,100,40);


        borrow.setBounds(50,100,200, 200);
        unBorrow.setBounds(250,100,200, 200);
        renew.setBounds(450,100,200, 200);
        see.setBounds(650,100,200, 200);
        add.setBounds(850,100,200, 200);
        delete.setBounds(1050,100,200, 200);
        returnToBack.setBounds(200,300,100,100);
        //
        nameLabel.setBounds(40,100,300,50);
        name.setBounds(40,150,300,50);
        secondNameLabel.setBounds(340,100,300,50);
        secondName.setBounds(340,150,300,50);
        titleLabel.setBounds(640,100,300,50);
        title.setBounds(640,150,300,50);
        typeLabel.setBounds(940,100,300,50);
        typeField.setBounds(940,150,300,50);
        uczenId.setBounds(40,250,300,50);
        uczenIdLabel.setBounds(40,200,300,50);
        addBookButton.setSize(100,100);
        addBookButton.setLocation(100,300);

        seeBook.setSize(100,100);
        seeBook.setLocation(100,300);

        deleteBook.setSize(100,100);
        deleteBook.setLocation(100,300);


        f.add(borrow);
        f.add(unBorrow);
        f.add(renew);
        f.add(see);
        f.add(add);
        f.add(delete);
        f.add(label);

        f.setSize(1280,800);
        borrowFrame.setSize(1280,800);
        unBorrowFrame.setSize(1280,800);
        renewFrame.setSize(1280,800);
        seeFrame.setSize(1280,800);
        deleteFrame.setSize(1280,800);
        addFrame.setSize(1280,800);

        f.getContentPane().setLayout(null);
        borrowFrame.getContentPane().setLayout(null);
        unBorrowFrame.getContentPane().setLayout(null);
        renewFrame.getContentPane().setLayout(null);
        seeFrame.getContentPane().setLayout(null);
        deleteFrame.getContentPane().setLayout(null);
        addFrame.getContentPane().setLayout(null);



        f.setLayout(null);
        f.setVisible(true);
    }
    public void viewBorrow(){
        viewFocus = 1;
        this.f.setVisible(false);
        this.borrowFrame.add(this.returnToBack);
        borrowFrame.add(nameLabel);
        borrowFrame.add(name);
        borrowFrame.add(secondNameLabel);
        borrowFrame.add(secondName);
        borrowFrame.add(titleLabel);
        borrowFrame.add(title);
        borrowFrame.add(typeLabel);
        borrowFrame.add(typeField);
        addBookButton.setText("wypożycz");
        borrowFrame.add(addBookButton);
        borrowFrame.add(returnToBack);
        borrowFrame.add(uczenId);
        borrowFrame.add(uczenIdLabel);

        this.borrowFrame.setVisible(true);
    }


    public void viewUnBorrow(){
        viewFocus = 2;
        this.f.setVisible(false);
        unBorrowFrame.add(nameLabel);
        unBorrowFrame.add(name);
        unBorrowFrame.add(secondNameLabel);
        unBorrowFrame.add(secondName);
        unBorrowFrame.add(titleLabel);
        unBorrowFrame.add(title);
        unBorrowFrame.add(typeLabel);
        unBorrowFrame.add(typeField);
        unBorrowFrame.add(addBookButton);
        addBookButton.setText("oddaj");
        unBorrowFrame.add(returnToBack);
        unBorrowFrame.add(uczenId);
        unBorrowFrame.add(uczenIdLabel);
        this.unBorrowFrame.add(this.returnToBack);
        this.unBorrowFrame.setVisible(true);

    }
    public void viewRenew(){
        viewFocus = 3;
        this.f.setVisible(false);
        renewFrame.add(nameLabel);
        renewFrame.add(name);
        renewFrame.add(secondNameLabel);
        renewFrame.add(secondName);
        renewFrame.add(titleLabel);
        renewFrame.add(title);
        renewFrame.add(typeLabel);
        renewFrame.add(typeField);
        addBookButton.setText("przedłuż");
        renewFrame.add(addBookButton);
        renewFrame.add(uczenId);
        renewFrame.add(uczenIdLabel);
        renewFrame.add(returnToBack);

        this.renewFrame.add(this.returnToBack);
        this.renewFrame.setVisible(true);

    }
    public void viewSee(){
        viewFocus = 4;

        this.f.setVisible(false);
        seeFrame.add(nameLabel);
        seeFrame.add(name);
        seeFrame.add(secondNameLabel);
        seeFrame.add(secondName);
        seeFrame.add(titleLabel);
        seeFrame.add(title);
        seeFrame.add(typeLabel);
        seeFrame.add(typeField);
        addBookButton.setText("zobacz");
        seeFrame.add(addBookButton);
        seeFrame.add(returnToBack);
        this.seeFrame.setVisible(true);

    }
    public void viewAdd(){
        viewFocus = 5;
        this.f.setVisible(false);
        addFrame.add(nameLabel);
        addFrame.add(name);
        addFrame.add(secondNameLabel);
        addFrame.add(secondName);
        addFrame.add(titleLabel);
        addFrame.add(title);
        addFrame.add(typeLabel);
        addFrame.add(typeField);
        addFrame.add(addBookButton);
        addFrame.add(returnToBack);
        this.addFrame.setVisible(true);

    }
    public void viewDeleteFrame(){
        viewFocus = 6;

        this.f.setVisible(false);
        deleteFrame.add(nameLabel);
        deleteFrame.add(name);
        deleteFrame.add(secondNameLabel);
        deleteFrame.add(secondName);
        deleteFrame.add(titleLabel);
        deleteFrame.add(title);
        deleteFrame.add(typeLabel);
        deleteFrame.add(typeField);
        addBookButton.setText("usuń");
        deleteFrame.add(addBookButton);
        deleteFrame.add(returnToBack);
        this.deleteFrame.setVisible(true);

    }
    public void returnToback(){
        viewFocus = 0;

        this.f.setVisible(true);
        this.borrowFrame.setVisible(false);
        this.unBorrowFrame.setVisible(false);
        this.renewFrame.setVisible(false);
        this.addFrame.setVisible(false);
        this.deleteFrame.setVisible(false);

        this.seeFrame.setVisible(false);

    }


    public void addBookFunction() {
        switch (viewFocus){
            case 0:
                break;
            case 1:
                System.out.println(name.getText()+" "+secondName.getText()+ " " + title.getText() + " " + typeField.getText() + " " +uczenId.getText());
                break;
            case 2:
                System.out.println(name.getText()+" "+secondName.getText()+ " " + title.getText() + " " + typeField.getText()+ " " +uczenId.getText());
                break;
            case 3:
                System.out.println(name.getText()+" "+secondName.getText()+ " " + title.getText() + " " + typeField.getText()+ " " +uczenId.getText());
                break;
            case 4:
                System.out.println(name.getText()+" "+secondName.getText()+ " " + title.getText() + " " + typeField.getText());
                break;
            case 5:
                System.out.println(name.getText()+" "+secondName.getText()+ " " + title.getText() + " " + typeField.getText());
                break;
            case 6:
                System.out.println(name.getText()+" "+secondName.getText()+ " " + title.getText() + " " + typeField.getText());
                break;

        }
    }

}
