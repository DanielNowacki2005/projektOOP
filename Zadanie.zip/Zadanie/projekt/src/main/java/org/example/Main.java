package org.example;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class Main {

public static void main(String[] args) throws IOException {

    //main window view concructor
    CreateViews root = new CreateViews();
    root.f.setTitle("biblioteka");
    Color color = new Color(155,100,100);
    root.f.getContentPane().setBackground(color);

    root.borrowFrame.getContentPane().setBackground(color);
    root.unBorrowFrame.getContentPane().setBackground(color);
    root.renewFrame.getContentPane().setBackground(color);
    root.seeFrame.getContentPane().setBackground(color);
    root.addFrame.getContentPane().setBackground(color);
    root.deleteFrame.getContentPane().setBackground(color);
    root.borrowFrame.setTitle("wypożycz");
    root.unBorrowFrame.setTitle("oddaj");
    root.renewFrame.setTitle("odnów");
    root.seeFrame.setTitle("zobacz");
    root.addFrame.setTitle("dodaj");
    root.deleteFrame.setTitle("usuń");
    //listeners that create views
    root.borrow.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.viewBorrow();}});
    root.unBorrow.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.viewUnBorrow();}});
    root.renew.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.viewRenew();}});
    root.see.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.viewSee();}});
    root.add.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.viewAdd();}});
    root.delete.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.viewDeleteFrame();}});
    root.addBookButton.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.addBookFunction();}});
    //button that return back to main view
    root.returnToBack.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent e) {root.returnToback();}

    });





    }}

