package org.example;

public interface IUser {
    public String name = null,secondName = null;
    public void delete();
    public void add();

}
